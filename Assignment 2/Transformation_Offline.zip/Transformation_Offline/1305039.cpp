#include <bits/stdc++.h>

#define pi (2*acos(0.0))

using namespace std;


class point{
    double **array;
public:
    point()
    {
        array = new double*[4];
        for(int i=0;i<4;i++) array[i] = new double[1];
        array[3][0] = 1;
    }
    point(double x,double y,double z)
    {
        array = new double*[4];
        for(int i=0;i<4;i++) array[i] = new double[1];
        array[0][0] = x;
        array[1][0] = y;
        array[2][0] = z;
        array[3][0] = 1;
    }
    double** getArray()
    {
        return array;
    }
    void setx(double x)
    {
        array[0][0] = x;
    }
    void sety(double y)
    {
       array[1][0] = y;
    }
    void setz(double z)
    {
       array[2][0] = z;
    }
    double getx()
    {
        return array[0][0];
    }
    double gety()
    {
        return array[1][0];
    }
    double getz()
    {
        return array[2][0];
    }
    double getw()
    {
        return array[3][0];
    }
    void processweight()
    {
        for(int i=0;i<4;i++) array[i][0] = array[i][0]/getw();
    }

    void normalize()
    {
        double sum = 0.0;
        for(int i=0;i<3;i++) sum += array[i][0]*array[i][0];
        sum = sqrt(sum);
        array[0][0] = array[0][0]/sum;
        array[1][0] = array[1][0]/sum;
        array[2][0] = array[2][0]/sum;
    }

    void print()
    {
        cout<<fixed;
        for(int i=0;i<3;i++)
        {
            cout<<array[i][0]<<" ";
        }
        cout<<endl;
    }
    void print(ofstream& os)
    {

        os<<fixed;
        for(int i=0;i<3;i++)
        {
            os<<setprecision(7)<<array[i][0]<<" ";
        }
        os<<endl;
    }


};

double dotproduct(point a, point b)
{
    return a.getx()*b.getx() + a.gety()*b.gety() + a.getz()*b.getz();
}

point crossproduct(point a,point b)
{
    point p;
    p.setx(a.gety()*b.getz() - a.getz()*b.gety());
    p.sety(-(a.getx()*b.getz() - b.getx()*a.getz()));
    p.setz(a.getx()*b.gety() - b.getx()*a.gety());
    return p;
}


point R(point x,point a,double theta)
{
    point result;
    double dot = dotproduct(a,x);
    point cross = crossproduct(a,x);

    double costheta = cos(theta*pi/180.0);
    double sintheta = sin(theta*pi/180.0);

    double p,q,r;
    p = costheta*x.getx()+ (1-costheta)*dot*a.getx()+ sintheta*cross.getx();
    q = costheta*x.gety()+ (1-costheta)*dot*a.gety()+ sintheta*cross.gety();
    r = costheta*x.getz()+ (1-costheta)*dot*a.getz()+ sintheta*cross.getz();

    result.setx(p);
    result.sety(q);
    result.setz(r);
    return result;
}


class matrix{
    double **array;
    string type;
public:

    matrix()
    {
        array = new double*[4];
        for(int i=0;i<4;i++) array[i] = new double[4];
    }
    double** getArray()
    {
        return array;
    }
    void identity()
    {
        type = "I";
        for(int i=0;i<4;i++)
        {
            for(int j=0;j<4;j++)
            {
                if(j==i) array[i][j] = 1;
                else array[i][j] = 0;
            }
        }
    }
    void translate(double tx, double ty, double tz)
    {
        type ="T";
        identity();
        array[0][3] = tx;
        array[1][3] = ty;
        array[2][3] = tz;
        array[3][3] = 1;
    }

    void scale(double x,double y,double z)
    {
        identity();
        array[0][0] = x;
        array[1][1] = y;
        array[2][2] = z;
    }

    void rotate(double angle, point a)
    {
        type = "R";
        identity();
        a.normalize();

        point iVector = point(1,0,0);
        point jVector = point(0,1,0);
        point kVector = point(0,0,1);

        point c1 = R(iVector,a,angle);
        point c2 = R(jVector,a,angle);
        point c3 = R(kVector,a,angle);

        array[0][0] = c1.getx();
        array[1][0] = c1.gety();
        array[2][0] = c1.getz();

        array[0][1] = c2.getx();
        array[1][1] = c2.gety();
        array[2][1] = c2.getz();

        array[0][2] = c3.getx();
        array[1][2] = c3.gety();
        array[2][2] = c3.getz();
    }

    void viewRotate(point l, point r, point u)
    {
        identity();
        array[0][0] = r.getx();
        array[0][1] = r.gety();
        array[0][2] = r.getz();

        array[1][0] = u.getx();
        array[1][1] = u.gety();
        array[1][2] = u.getz();

        array[2][0] = -l.getx();
        array[2][1] = -l.gety();
        array[2][2] = -l.getz();
    }

    void projection(double near,double far,double t,double r)
    {
       identity();
       array[0][0] = near/r;
       array[1][1] = near/t;
       array[2][2] = -(far+near)/(far-near);
       array[2][3] = -(2*far*near)/(far-near);
       array[3][2] = -1;
       array[3][3] = 0;
    }

    string getType()
    {
        return type;
    }

    void print()
    {
        cout<<fixed;
       for(int i=0;i<4;i++)
        {
            for(int j=0;j<4;j++)
            {
                cout<<setprecision(3)<<array[i][j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl;
    }

};

matrix matmult(matrix x,matrix y)
{
        matrix mat;
        double **a,**b;
        a = x.getArray();
        b = y.getArray();

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                mat.getArray()[i][j] = 0;
                for (int k = 0; k < 4; k++)
                {
                    mat.getArray()[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        return mat;
}

point pointmult(matrix x,point y)
{
        double **a,**b;
        point p;
        a = x.getArray();
        b = y.getArray();

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 1; j++)
            {
                p.getArray()[i][j] = 0;
                for (int k = 0; k < 4; k++)
                {
                    p.getArray()[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return p;
}

int main()
{
    double eyeX = 0;
    double eyeY = 0;
    double eyeZ = 0;

    double lookX = 0;
    double lookY = 0;
    double lookZ = 0;

    double upX = 0;
    double upY = 0;
    double upZ = 0;

    double fovY = 0;
    double aspectRatio = 0;
    double near = 0;
    double far  = 0;

    stack<matrix> glstack;

    matrix transformMat;
    transformMat.identity();


    ifstream cin("scene.txt");
    ofstream stage1("stage1.txt");
    ofstream stage2("stage2.txt");
    ofstream stage3("stage3.txt");


    cin>>eyeX>>eyeY>>eyeZ;

    cin>>lookX>>lookY>>lookZ;

    cin>>upX>>upY>>upZ;

    cin>>fovY;
    cin>>aspectRatio;
    cin>>near;
    cin>>far;

    point l(lookX-eyeX,lookY-eyeY,lookZ-eyeZ);
    l.normalize();
    point up(upX,upY,upZ);
    point r = crossproduct(l,up);
    r.normalize();
    point u = crossproduct(r,l);


    matrix T;
    T.translate(-eyeX,-eyeY,-eyeZ);

    matrix R;
    R.viewRotate(l,r,u);

    matrix V = matmult(R,T);


    double fovX = fovY * aspectRatio;
    double project_t = near * tan(fovY*pi/360.0);
    double project_r = near * tan(fovX*pi/360.0);

    matrix P;
    P.projection(near,far,project_t,project_r);


    string command ="";
    while(true)
    {
       cin>>command;
       if(command=="triangle"){
           for(int i=0;i<3;i++)
           {
               double x,y,z;
               cin>>x>>y>>z;
               point p(x,y,z);
               point output1,output2,output3;
               output1 = pointmult(transformMat,p);
               if(output1.getw() !=1) output1.processweight();
               output1.print(stage1);

               output2 = pointmult(V,output1);
               if(output2.getw() !=1) output2.processweight();
               output2.print(stage2);

               output3 = pointmult(P,output2);
               if(output3.getw() !=1) output3.processweight();
               output3.print(stage3);
           }
           stage1<<endl;
           stage2<<endl;
           stage3<<endl;
       }
       else if(command=="translate")
       {
           double x,y,z;
           cin>>x>>y>>z;
           matrix mat;
           mat.translate(x,y,z);
           transformMat = matmult(transformMat,mat);
       }
       else if(command=="scale")
       {
           double x,y,z;
           cin>>x>>y>>z;
           matrix mat;
           mat.scale(x,y,z);
           transformMat = matmult(transformMat,mat);
       }
       else if(command=="rotate")
       {
           double angle,x,y,z;
           cin>>angle>>x>>y>>z;
           point p(x,y,z);
           matrix mat;
           mat.rotate(angle,p);
           transformMat = matmult(transformMat,mat);
       }
       else if(command=="push")
       {
           glstack.push(transformMat);

       }
       else if(command=="pop")
       {
           transformMat = glstack.top();
           glstack.pop();
       }
       else if(command=="end"){
            break;
       }
    }

}
